"""
Pipeline d'ingestion vidéo async.
Supporte :
  - Transcription YouTube via youtube-transcript-api
  - Texte brut / fichiers .srt / .vtt
"""

import asyncio
import logging
import re
from typing import Any

from llama_index.core import Document, VectorStoreIndex
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core.node_parser import SentenceSplitter
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import TranscriptsDisabled, NoTranscriptFound

logger = logging.getLogger(__name__)

_YT_REGEX = re.compile(
    r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([A-Za-z0-9_-]{11})"
)


def _extract_video_id(url: str) -> str | None:
    match = _YT_REGEX.search(url)
    return match.group(1) if match else None


def _fetch_transcript(video_id: str, languages: list[str] | None = None) -> str:
    """Récupère et concatène la transcription YouTube (synchrone)."""
    langs = languages or ["fr", "en", "auto"]
    transcript_list = YouTubeTranscriptApi.get_transcript(video_id, languages=langs)
    return " ".join(entry["text"] for entry in transcript_list)


def _parse_srt_vtt(raw: str) -> str:
    """Nettoie les fichiers SRT/VTT pour ne garder que le texte."""
    # Supprime les horodatages et balises HTML
    text = re.sub(r"\d{2}:\d{2}:\d{2}[.,]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[.,]\d{3}", "", raw)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"^\d+$", "", text, flags=re.MULTILINE)
    text = re.sub(r"WEBVTT.*?\n", "", text)
    return " ".join(text.split())


class VideoIngestionPipeline:
    """Pipeline d'ingestion async pour documents vidéo."""

    def __init__(self, index: VectorStoreIndex):
        self.index = index
        self._pipeline = IngestionPipeline(
            transformations=[
                SentenceSplitter(chunk_size=512, chunk_overlap=64),
            ]
        )

    async def ingest_youtube_url(
        self,
        url: str,
        extra_metadata: dict[str, Any] | None = None,
    ) -> int:
        """
        Ingère une vidéo YouTube par son URL.
        Retourne le nombre de chunks insérés.
        """
        video_id = _extract_video_id(url)
        if not video_id:
            logger.error("URL YouTube invalide : %s", url)
            raise ValueError(f"Impossible d'extraire l'ID vidéo depuis : {url}")

        logger.info("📥 Récupération de la transcription pour %s…", video_id)
        try:
            transcript = await asyncio.to_thread(_fetch_transcript, video_id)
        except (TranscriptsDisabled, NoTranscriptFound) as exc:
            logger.error("Transcription indisponible pour %s : %s", video_id, exc)
            raise RuntimeError(f"Transcription indisponible pour {video_id}") from exc

        metadata = {
            "source": "youtube",
            "video_id": video_id,
            "url": url,
            **(extra_metadata or {}),
        }
        return await self._insert_text(transcript, metadata)

    async def ingest_text(
        self,
        raw_text: str,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        """
        Ingère un texte brut (ou contenu SRT/VTT nettoyé).
        Retourne le nombre de chunks insérés.
        """
        # Nettoyage SRT/VTT si applicable
        if "-->" in raw_text:
            raw_text = _parse_srt_vtt(raw_text)

        return await self._insert_text(raw_text, metadata or {})

    async def _insert_text(self, text: str, metadata: dict[str, Any]) -> int:
        """Transforme le texte en nœuds et les insère dans l'index."""
        doc = Document(text=text, metadata=metadata)

        nodes = await asyncio.to_thread(self._pipeline.run, documents=[doc])
        logger.info("📦 %d chunks générés pour %s", len(nodes), metadata.get("source", "?"))

        await asyncio.to_thread(self.index.insert_nodes, nodes)
        logger.info("✅ %d chunks insérés dans l'index.", len(nodes))
        return len(nodes)
