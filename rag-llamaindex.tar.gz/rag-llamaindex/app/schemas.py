"""Schémas Pydantic pour l'API RAG."""

from typing import Any
from pydantic import BaseModel, HttpUrl, Field


class IngestRequest(BaseModel):
    url: str = Field(..., description="URL YouTube à ingérer")
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Métadonnées supplémentaires (titre, auteur, etc.)",
    )


class IngestResponse(BaseModel):
    message: str
    url: str
    status: str


class ChatRequest(BaseModel):
    question: str = Field(..., description="Question à poser au RAG")
    top_k: int = Field(default=5, ge=1, le=20, description="Nombre de chunks à récupérer")


class ChatResponse(BaseModel):
    answer: str
    sources: list[dict[str, Any]]
    model: str


class HealthResponse(BaseModel):
    status: str
    index_ready: bool


class IndexStatsResponse(BaseModel):
    total_chunks: int
