# RAG LlamaIndex — Vidéo 🎬

Pipeline RAG asynchrone construit avec **LlamaIndex**, **FastAPI** et **ChromaDB**.  
Il transcrit des vidéos YouTube, les découpe en chunks, les vectorise et expose une API de Q&R.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      FastAPI (async)                    │
│                                                         │
│  POST /ingest/url ──► VideoIngestionPipeline            │
│  POST /ingest/file      │                               │
│                         ▼                               │
│              YouTubeTranscriptAPI                       │
│                         │                               │
│              SentenceSplitter (chunks)                  │
│                         │                               │
│              OpenAIEmbedding (vectors)                  │
│                         │                               │
│              ChromaDB (persistance)                     │
│                         │                               │
│  POST /chat ◄──── VectorStoreIndex.query()              │
│  POST /chat/stream      │                               │
│                    OpenAI LLM                           │
└─────────────────────────────────────────────────────────┘
```

---

## Démarrage rapide

```bash
# 1. Cloner et configurer
cp .env.example .env
# Editez .env et ajoutez votre OPENAI_API_KEY

# 2. Lancer avec Docker Compose
docker compose up --build -d

# 3. Vérifier que l'API est prête
curl http://localhost:8000/health
```

---

## Utilisation de l'API

### Ingérer une vidéo YouTube
```bash
curl -X POST http://localhost:8000/ingest/url \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "metadata": {"titre": "Ma vidéo", "auteur": "Rick Astley"}
  }'
```

### Ingérer un fichier de sous-titres (.srt / .vtt / .txt)
```bash
curl -X POST http://localhost:8000/ingest/file \
  -F "file=@ma_transcription.srt"
```

### Poser une question (réponse complète)
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"question": "De quoi parle cette vidéo ?", "top_k": 5}'
```

### Poser une question (streaming SSE)
```bash
curl -X POST http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"question": "Résume les points clés.", "top_k": 5}'
```

### Statistiques de l'index
```bash
curl http://localhost:8000/stats
```

### Réinitialiser l'index
```bash
curl -X DELETE http://localhost:8000/index
```

---

## Variables d'environnement

| Variable | Défaut | Description |
|---|---|---|
| `OPENAI_API_KEY` | — | **Obligatoire** — clé API OpenAI |
| `OPENAI_MODEL` | `gpt-4o-mini` | Modèle LLM pour la génération |
| `EMBED_MODEL` | `text-embedding-3-small` | Modèle d'embeddings |
| `LLM_TEMPERATURE` | `0.1` | Température du LLM |
| `CHUNK_SIZE` | `512` | Taille des chunks (tokens) |
| `CHUNK_OVERLAP` | `64` | Chevauchement entre chunks |
| `WORKERS` | `4` | Nombre de workers Uvicorn |
| `PORT` | `8000` | Port d'écoute |

---

## Développement local (sans Docker)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

export OPENAI_API_KEY=sk-...
export CHROMA_PATH=./chroma_db

uvicorn app.main:app --reload --port 8000
```

---

## Commandes Docker utiles

```bash
# Logs en temps réel
docker compose logs -f rag-api

# Reconstruire après modification du code
docker compose up --build -d

# Inspecter le volume ChromaDB
docker volume inspect rag-llamaindex_chroma_data

# Arrêter sans perdre les données
docker compose stop

# Tout supprimer (⚠️ données perdues)
docker compose down -v
```
